#!/bin/sh
# Add the standalone toolchain to the search path.
export PATH=$PATH:/home/yangjianying/disk3/readline/toolchain_arm/bin

# Tell configure what tools to use.
target_host=arm-linux-androideabi
export AR=$target_host-ar
export AS=$target_host-clang
export CC=$target_host-clang
export CXX=$target_host-clang++
export LD=$target_host-ld
export STRIP=$target_host-strip

# Tell configure what flags Android requires.
#export CFLAGS="-fPIE -fPIC"
#export LDFLAGS="-pie"

./configure --host=$target_host --prefix=/home/yangjianying/disk3/readline/readline-8.0_arm/install_ \
	&& make \
	&& make install


